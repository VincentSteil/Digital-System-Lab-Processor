Digital-System-Lab-Processor
============================

This is the second and third part of the Digital System Laboratory coded in Verilog. 

It contains a single cycle modified Harvardprocessor that interfaces with multiple peripherals accessed via memory mapped I/O.

Peripherals include a PS2 mouse port, a VGA port, and an IR controller.

Besides the skeleton code that was provided to us, the collaborators on this are:

Vincent Steil

Finn Tessier-lavigne

Mihail Dimitrov Mitev
